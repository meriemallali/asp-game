import "./App.css";
// import Model from "./Model";
// import Model from "./Maincharacter_model";
import Main from "./MainCharacter.js";

const App = () => {
  return (
      <Main/>
  );
};

export default App;
