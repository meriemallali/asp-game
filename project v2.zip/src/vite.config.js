// vite.config.js
export default {
  optimizeDeps: {
    include: ['three'],
  },
};
